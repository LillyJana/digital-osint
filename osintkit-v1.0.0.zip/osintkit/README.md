# OSINTKit

A dependency-free (Python standard library only) command-line toolkit for
**OSINT reconnaissance** and **digital forensics**, built for investigative work.

```
./osintkit.sh osint domain example.com --all
./osintkit.sh forensics hash evidence/* --write hashes.txt
```

## Requirements

- Python 3.8+
- No pip packages required. Internet access is needed for the live OSINT lookups.

## Quick start

```bash
cd osintkit
chmod +x osintkit.sh
./osintkit.sh --help
```

## OSINT commands

| Command | What it does |
|---|---|
| `osint domain <d> [--whois] [--subdomains] [--all]` | DNS records (A/AAAA/MX/NS/TXT/SOA/CAA) via a built-in DNS client, raw WHOIS over TCP/43, subdomain enumeration via crt.sh |
| `osint ip <ip\|host>` | Geolocation (ip-api.com), reverse DNS, AbuseIPDB reputation, Shodan host data |
| `osint email <addr>` | Syntax + MX validation, Gravatar check, HaveIBeenPwned breach lookup |
| `osint username <handle> [--delay N]` | Presence check across ~30 public platforms |
| `osint url <url>` | Redirect-chain tracing, response headers, VirusTotal + urlscan.io reputation |

Every OSINT command accepts `--json` (machine-readable output) and
`--output FILE` (write results to a file).

## Forensics commands

| Command | What it does |
|---|---|
| `forensics hash <files> [--algo ...] [--verify LIST] [--write OUT]` | MD5/SHA-1/SHA-256/SHA-512 hashing and verification against hash lists |
| `forensics fileinfo <file>` | Magic-byte identification, entropy (packed/encrypted heuristic), PE header summary, ZIP listing |
| `forensics exif <image>` | JPEG EXIF and PNG text-chunk metadata, incl. GPS coordinates + map link |
| `forensics strings <file> [-n N] [--unicode] [--iocs] [--iocs-only]` | Printable-string extraction with IOC summarisation (URLs, emails, IPs, paths) |
| `forensics timeline <dir> [--hash] [--since ...] [-o timeline.csv]` | Filesystem timeline (mtime/atime/ctime) as CSV, sorted chronologically |
| `forensics carve <image> [-o carved/]` | Recover JPEG/PNG/GIF/PDF/ZIP files from a raw dump by header/footer carving |
| `forensics logparse <log> [--top N]` | Top talker IPs, brute-force sources, referenced URLs/emails, error samples |
| `forensics pcap <file.pcap> [--top N]` | Triage: protocols, top talkers, ports, DNS queries, HTTP hosts, largest flows |

## API keys (optional)

Free sources work out of the box. These keys unlock the enriched lookups:

```bash
./osintkit.sh config set VIRUSTOTAL_API_KEY <key>
./osintkit.sh config set ABUSEIPDB_API_KEY <key>
./osintkit.sh config set SHODAN_API_KEY <key>
./osintkit.sh config set HIBP_API_KEY <key>        # HaveIBeenPwned
./osintkit.sh config set URLSCAN_API_KEY <key>
./osintkit.sh config list
```

Keys are stored with `0600` permissions in `~/.config/osintkit/config.json`;
environment variables of the same name take precedence.

## Examples

```bash
# Full domain recon, JSON report to file
./osintkit.sh osint domain suspect-domain.com --all --json -o recon.json

# Hash a seized directory and verify later
./osintkit.sh forensics hash /mnt/evidence/* --write hashes.txt
./osintkit.sh forensics hash /mnt/evidence/* --verify hashes.txt

# Timeline of what changed on a host in the last incident window
./osintkit.sh forensics timeline /mnt/evidence --hash --since "2026-09-01 00:00:00 UTC"

# Triage a capture
./osintkit.sh forensics pcap capture.pcap --top 30 -o triage.json

# Pull IOCs out of a suspicious binary
./osintkit.sh forensics strings malware.bin --unicode --iocs-only
```

## Notes for investigators

- Username/platform checks are best-effort heuristics - always verify a hit
  manually before treating it as evidence.
- Carved files are candidates; validate each one before relying on it.
- `timeline` reads file metadata only; it never modifies the evidence.
- The `pcap` triager handles classic pcap (not pcapng); use Wireshark for
  full dissection.
- Nothing here phones home except the lookups you explicitly run.
