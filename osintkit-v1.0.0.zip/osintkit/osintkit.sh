#!/usr/bin/env bash
# Launcher for OSINTKit - run from the osintkit directory or anywhere.
# Usage: ./osintkit <command> [options]
exec python3 -m osintkit "$@"
