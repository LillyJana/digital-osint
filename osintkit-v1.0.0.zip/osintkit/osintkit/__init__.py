"""OSINTKit - OSINT and digital forensics toolkit for investigations.

A dependency-free (stdlib only) command-line toolkit with two wings:
  osint      -> domain, ip, email, username and url reconnaissance
  forensics  -> hashing, file identification, metadata, strings,
                timeline building, file carving, log and pcap analysis
"""

__version__ = "1.0.0"
__author__ = "Built by Lally for investigations work"
