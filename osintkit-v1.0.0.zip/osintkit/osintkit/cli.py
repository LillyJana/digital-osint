"""Command-line interface for OSINTKit."""

import argparse
import sys

from . import config
from .utils import Colors, err, info, ok


def _add_common(parser):
    parser.add_argument("--json", action="store_true",
                        help="emit machine-readable JSON instead of pretty text")
    parser.add_argument("--output", "-o", default=None,
                        help="write output to a file (JSON mode writes JSON there)")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="osintkit",
        description="OSINT and digital forensics toolkit for investigations.")
    parser.add_argument("--version", action="version", version="OSINTKit 1.0.0")
    parser.add_argument("--no-color", action="store_true", help="disable colored output")
    sub = parser.add_subparsers(dest="command", required=True)

    # ---------- config ----------
    p_cfg = sub.add_parser("config", help="manage API keys")
    cfg_sub = p_cfg.add_subparsers(dest="cfg_cmd", required=True)
    p_set = cfg_sub.add_parser("set", help="store an API key")
    p_set.add_argument("key", help="key name, e.g. VIRUSTOTAL_API_KEY")
    p_set.add_argument("value", help="the API key value")
    cfg_sub.add_parser("list", help="show which keys are configured")
    p_clear = cfg_sub.add_parser("clear", help="remove a stored key")
    p_clear.add_argument("key", help="key name to remove")

    # ---------- osint ----------
    p_osint = sub.add_parser("osint", help="open-source intelligence")
    o_sub = p_osint.add_subparsers(dest="osint_cmd", required=True)

    p_dom = o_sub.add_parser("domain", help="DNS, WHOIS, subdomain enumeration")
    p_dom.add_argument("domain")
    p_dom.add_argument("--whois", action="store_true", help="include WHOIS lookup")
    p_dom.add_argument("--subdomains", action="store_true",
                       help="enumerate subdomains via crt.sh")
    p_dom.add_argument("--all", action="store_true",
                       help="enable whois + subdomains")
    _add_common(p_dom)

    p_ip = o_sub.add_parser("ip", help="IP geolocation, reputation, Shodan")
    p_ip.add_argument("ip", help="IPv4/IPv6 address or hostname")
    _add_common(p_ip)

    p_email = o_sub.add_parser("email", help="email validation, Gravatar, breaches")
    p_email.add_argument("email")
    _add_common(p_email)

    p_user = o_sub.add_parser("username", help="handle presence across platforms")
    p_user.add_argument("username")
    p_user.add_argument("--delay", type=float, default=0.4,
                        help="seconds between site checks (default 0.4)")
    p_user.add_argument("--verbose", "-v", action="store_true",
                        help="also list inconclusive checks")
    _add_common(p_user)

    p_url = o_sub.add_parser("url", help="redirect chain, headers, reputation")
    p_url.add_argument("url")
    _add_common(p_url)

    # ---------- forensics ----------
    p_for = sub.add_parser("forensics", help="digital forensics helpers")
    f_sub = p_for.add_subparsers(dest="for_cmd", required=True)

    p_hash = f_sub.add_parser("hash", help="hash files (md5/sha1/sha256/sha512)")
    p_hash.add_argument("files", nargs="+")
    p_hash.add_argument("--algo", nargs="+", choices=["md5", "sha1", "sha256", "sha512"],
                        help="limit to these algorithms")
    p_hash.add_argument("--verify", default=None, metavar="HASHLIST",
                        help="verify files against a hash list file")
    p_hash.add_argument("--write", default=None, metavar="OUT",
                        help="write sha256 hashes to OUT in 'hash  file' format")
    _add_common(p_hash)

    p_fi = f_sub.add_parser("fileinfo", help="identify file type, entropy, PE/ZIP details")
    p_fi.add_argument("file")
    _add_common(p_fi)

    p_exif = f_sub.add_parser("exif", help="extract image metadata (JPEG/PNG)")
    p_exif.add_argument("image")
    _add_common(p_exif)

    p_str = f_sub.add_parser("strings", help="extract printable strings")
    p_str.add_argument("file")
    p_str.add_argument("-n", "--min-length", type=int, default=4)
    p_str.add_argument("--unicode", action="store_true",
                       help="also extract UTF-16 strings")
    p_str.add_argument("--iocs", action="store_true",
                       help="summarize indicators (URLs, emails, IPs, paths)")
    p_str.add_argument("--iocs-only", action="store_true",
                       help="show only the indicator summary")
    p_str.add_argument("--limit", type=int, default=200,
                       help="max strings to print (0 = all)")
    _add_common(p_str)

    p_tl = f_sub.add_parser("timeline", help="build a CSV filesystem timeline")
    p_tl.add_argument("directory")
    p_tl.add_argument("--hash", action="store_true",
                      help="include SHA-256 per file (slower)")
    p_tl.add_argument("--since", default=None,
                      help="only entries on/after 'YYYY-MM-DD HH:MM:SS UTC'")
    p_tl.add_argument("--tail", type=int, default=10,
                      help="print N most recent entries")
    p_tl.add_argument("--output", "-o", default="timeline.csv")

    p_carve = f_sub.add_parser("carve", help="carve files from a raw image by headers")
    p_carve.add_argument("image", help="raw dump / disk image")
    p_carve.add_argument("--output", "-o", default="carved",
                         help="output directory (default: carved)")
    p_carve.add_argument("--json", action="store_true")

    p_log = f_sub.add_parser("logparse", help="triage a text log file")
    p_log.add_argument("logfile")
    p_log.add_argument("--top", type=int, default=20)
    _add_common(p_log)

    p_pcap = f_sub.add_parser("pcap", help="triage a pcap capture file")
    p_pcap.add_argument("pcap")
    p_pcap.add_argument("--top", type=int, default=20)
    _add_common(p_pcap)

    return parser


def run_config(args):
    if args.cfg_cmd == "set":
        config.set_key(args.key, args.value)
        ok(f"Stored {args.key.strip().upper()}")
    elif args.cfg_cmd == "clear":
        config.clear_key(args.key)
        ok(f"Removed {args.key.strip().upper()}")
    elif args.cfg_cmd == "list":
        known = config.list_keys()
        print("\n  Configured API keys:")
        for name, desc in config.KNOWN_KEYS.items():
            src = known.get(name)
            mark = f"yes ({src})" if src else "no"
            print(f"    [{mark:16}] {name:20} - {desc}")
        print()


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.no_color:
        Colors.disable()
    if getattr(args, "json", False):
        from .utils import set_quiet
        set_quiet(True)

    try:
        if args.command == "config":
            run_config(args)
        elif args.command == "osint":
            from .osint import domain, ip, email, username, url
            if args.osint_cmd == "domain":
                if args.all:
                    args.whois = args.subdomains = True
                domain.run(args)
            elif args.osint_cmd == "ip":
                ip.run(args)
            elif args.osint_cmd == "email":
                email.run(args)
            elif args.osint_cmd == "username":
                username.run(args)
            elif args.osint_cmd == "url":
                url.run(args)
        elif args.command == "forensics":
            from .forensics import hash as f_hash, fileinfo, exif, strings, timeline, carve, logparse, pcap
            if args.for_cmd == "hash":
                f_hash.run(args)
            elif args.for_cmd == "fileinfo":
                fileinfo.run(args)
            elif args.for_cmd == "exif":
                exif.run(args)
            elif args.for_cmd == "strings":
                strings.run(args)
            elif args.for_cmd == "timeline":
                timeline.run(args)
            elif args.for_cmd == "carve":
                carve.run(args)
            elif args.for_cmd == "logparse":
                logparse.run(args)
            elif args.for_cmd == "pcap":
                pcap.run(args)
    except KeyboardInterrupt:
        err("\nInterrupted.")
        return 130
    except SystemExit:
        raise
    except RuntimeError as exc:
        err(str(exc))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
