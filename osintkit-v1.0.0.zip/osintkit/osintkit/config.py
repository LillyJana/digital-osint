"""API key and configuration management.

Keys are read from (in order of precedence):
  1. Environment variables (e.g. VIRUSTOTAL_API_KEY)
  2. ~/.config/osintkit/config.json

Set them with:  python -m osintkit config set VIRUSTOTAL_API_KEY <key>
"""

import json
import os

CONFIG_DIR = os.path.expanduser("~/.config/osintkit")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

KNOWN_KEYS = {
    "VIRUSTOTAL_API_KEY": "VirusTotal - URL/file reputation lookups",
    "ABUSEIPDB_API_KEY": "AbuseIPDB - IP reputation and abuse reports",
    "SHODAN_API_KEY": "Shodan - internet-exposed device/service search",
    "HIBP_API_KEY": "HaveIBeenPwned - breach lookups for email addresses",
    "URLSCAN_API_KEY": "urlscan.io - URL scanning and search",
}


def _read_file():
    if not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def get_key(name):
    """Return an API key, preferring the environment over the config file."""
    env = os.environ.get(name)
    if env:
        return env.strip()
    return _read_file().get(name, "").strip() or None


def set_key(name, value):
    name = name.strip().upper()
    os.makedirs(CONFIG_DIR, exist_ok=True)
    data = _read_file()
    data[name] = value.strip()
    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    # Lock the file down: API keys live here.
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except OSError:
        pass


def clear_key(name):
    name = name.strip().upper()
    data = _read_file()
    data.pop(name, None)
    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def list_keys():
    """Return {name: source} for every known key that is configured."""
    result = {}
    file_data = _read_file()
    for name in KNOWN_KEYS:
        if os.environ.get(name):
            result[name] = "environment"
        elif file_data.get(name):
            result[name] = "config file"
    return result
