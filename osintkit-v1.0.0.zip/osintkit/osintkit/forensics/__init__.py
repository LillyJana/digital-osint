"""Digital forensics subpackage: evidence acquisition and analysis helpers."""
