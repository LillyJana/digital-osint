"""File carving: recover embedded files from a raw image/dump by headers.

Scans for known file signatures and extracts each candidate to the
output directory. Best-effort - validate every carved file afterwards.
"""

import os

from ..utils import info, ok, warn

# (extension, header, footer or None, max_size)
CARVE_SPECS = [
    ("jpg", b"\xFF\xD8\xFF", b"\xFF\xD9", 20 * 1024 * 1024),
    ("png", b"\x89PNG\r\n\x1a\n", b"IEND\xae\x42\x60\x82", 50 * 1024 * 1024),
    ("gif", b"GIF89a", b"\x00\x3B", 20 * 1024 * 1024),
    ("gif", b"GIF87a", b"\x00\x3B", 20 * 1024 * 1024),
    ("pdf", b"%PDF-", b"%%EOF", 100 * 1024 * 1024),
    ("zip", b"PK\x03\x04", None, 500 * 1024 * 1024),
]


def carve(data, outdir, specs=CARVE_SPECS):
    os.makedirs(outdir, exist_ok=True)
    recovered = []
    for ext, header, footer, max_size in specs:
        start = 0
        n = 0
        while True:
            idx = data.find(header, start)
            if idx == -1:
                break
            end = len(data)
            if footer:
                fidx = data.find(footer, idx + len(header))
                if fidx != -1:
                    end = min(fidx + len(footer), idx + max_size)
                else:
                    end = min(idx + max_size, len(data))
            else:
                end = min(idx + max_size, len(data))
            n += 1
            fname = f"carved_{idx:010d}_{n:03d}.{ext}"
            fpath = os.path.join(outdir, fname)
            with open(fpath, "wb") as fh:
                fh.write(data[idx:end])
            recovered.append({"file": fpath, "offset": idx,
                              "size": end - idx, "type": ext})
            start = idx + 1  # allow overlapping finds
    return recovered


def run(args):
    from ..utils import emit_json

    if not os.path.isfile(args.image):
        raise SystemExit(f"Not a file: {args.image}")
    size = os.path.getsize(args.image)
    info(f"Reading {args.image} ({size} bytes) ...")
    with open(args.image, "rb") as fh:
        data = fh.read()

    info(f"Carving with {len(CARVE_SPECS)} signatures ...")
    recovered = carve(data, args.output)

    if args.json:
        emit_json(recovered)
        return

    if not recovered:
        warn("Nothing carved - no known headers found.")
        return
    print(f"\n  Recovered {len(recovered)} file(s) into {args.output}/")
    for r in recovered:
        print(f"    [{r['type']}] offset={r['offset']} size={r['size']} -> {r['file']}")
    warn("Carved files are candidates - verify each one before relying on it.")
    ok("Carving complete.")
