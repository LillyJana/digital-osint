"""Metadata extraction: JPEG EXIF and PNG text chunks, dependency-free.

Also reports GPS coordinates when present - often the single most
valuable field in image-based investigations.
"""

import os
import struct

from ..utils import warn

# EXIF tag ids we care about
TAGS = {
    0x010F: "Make", 0x0110: "Model", 0x0131: "Software", 0x0132: "DateTime",
    0x9003: "DateTimeOriginal", 0x9004: "DateTimeDigitized",
    0x829A: "ExposureTime", 0x829D: "FNumber", 0x8827: "ISOSpeed",
    0x0100: "ImageWidth", 0x0101: "ImageHeight",
    0x9286: "UserComment", 0x010E: "ImageDescription",
    0x013B: "Artist", 0x8298: "Copyright",
    0xA002: "PixelXDimension", 0xA003: "PixelYDimension",
}
GPS_TAGS = {0: "GPSVersion", 1: "GPSLatitudeRef", 2: "GPSLatitude",
            3: "GPSLongitudeRef", 4: "GPSLongitude", 6: "GPSAltitude"}

TYPE_SIZES = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8}


def _read_value(data, offset, tiff_start, endian, ftype, count, val_offset):
    size = TYPE_SIZES.get(ftype, 1) * count
    if size <= 4:
        raw = val_offset
        at = offset + 8
    else:
        at = tiff_start + struct.unpack(endian + "I", val_offset)[0]
        raw = data[at:at + size]
    try:
        if ftype == 2:  # ASCII
            return raw.split(b"\x00")[0].decode("utf-8", "replace").strip()
        if ftype == 3:
            vals = struct.unpack(endian + "H" * count, raw[:2 * count])
            return vals[0] if count == 1 else list(vals)
        if ftype == 4:
            vals = struct.unpack(endian + "I" * count, raw[:4 * count])
            return vals[0] if count == 1 else list(vals)
        if ftype == 5:  # rational
            vals = []
            for i in range(count):
                n, d = struct.unpack(endian + "II", raw[i * 8:i * 8 + 8])
                vals.append(n / d if d else 0)
            return vals[0] if count == 1 else vals
        if ftype == 10:  # signed rational
            vals = []
            for i in range(count):
                n, d = struct.unpack(endian + "ii", raw[i * 8:i * 8 + 8])
                vals.append(n / d if d else 0)
            return vals[0] if count == 1 else vals
        return raw.hex()
    except (struct.error, IndexError):
        return None


def _parse_ifd(data, ifd_offset, tiff_start, endian, tag_names):
    out = {}
    try:
        count = struct.unpack(endian + "H", data[ifd_offset:ifd_offset + 2])[0]
    except struct.error:
        return out
    for i in range(min(count, 200)):
        off = ifd_offset + 2 + i * 12
        try:
            tag, ftype, ncount = struct.unpack(endian + "HHI", data[off:off + 8])
        except struct.error:
            break
        value = _read_value(data, off, tiff_start, endian, ftype, ncount, data[off + 8:off + 12])
        name = tag_names.get(tag, f"Tag_{tag:#06x}")
        if value not in (None, "", b""):
            out[name] = value
    return out


def parse_jpeg_exif(path):
    with open(path, "rb") as fh:
        data = fh.read()
    if not data.startswith(b"\xFF\xD8\xFF"):
        return None
    pos = 2
    while pos < len(data):
        if data[pos] != 0xFF:
            break
        marker = data[pos + 1]
        if marker == 0xE1:  # APP1 - EXIF lives here
            length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
            segment = data[pos + 4:pos + 2 + length]
            if segment.startswith(b"Exif\x00\x00"):
                return _parse_tiff(segment[6:])
        elif marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            pos += 2
            continue
        else:
            length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
            pos += 2 + length
            continue
        pos += 2
    return {}


def _parse_tiff(tiff):
    if tiff[:2] == b"II":
        endian = "<"
    elif tiff[:2] == b"MM":
        endian = ">"
    else:
        return {}
    try:
        if struct.unpack(endian + "H", tiff[2:4])[0] != 42:
            return {}
        ifd0 = struct.unpack(endian + "I", tiff[4:8])[0]
    except struct.error:
        return {}
    meta = _parse_ifd(tiff, ifd0, 0, endian, TAGS)
    # EXIF sub-IFD
    exif_ptr = None
    try:
        count = struct.unpack(endian + "H", tiff[ifd0:ifd0 + 2])[0]
        for i in range(min(count, 200)):
            off = ifd0 + 2 + i * 12
            tag = struct.unpack(endian + "H", tiff[off:off + 2])[0]
            if tag == 0x8769:
                exif_ptr = struct.unpack(endian + "I", tiff[off + 8:off + 12])[0]
    except struct.error:
        pass
    if exif_ptr:
        meta.update(_parse_ifd(tiff, exif_ptr, 0, endian, TAGS))
    # GPS sub-IFD
    gps_ptr = None
    try:
        count = struct.unpack(endian + "H", tiff[ifd0:ifd0 + 2])[0]
        for i in range(min(count, 200)):
            off = ifd0 + 2 + i * 12
            tag = struct.unpack(endian + "H", tiff[off:off + 2])[0]
            if tag == 0x8825:
                gps_ptr = struct.unpack(endian + "I", tiff[off + 8:off + 12])[0]
    except struct.error:
        pass
    gps = {}
    if gps_ptr:
        gps = _parse_ifd(tiff, gps_ptr, 0, endian, GPS_TAGS)
    if gps:
        meta["GPS"] = gps
        lat = _dms_to_decimal(gps.get("GPSLatitude"), gps.get("GPSLatitudeRef"))
        lon = _dms_to_decimal(gps.get("GPSLongitude"), gps.get("GPSLongitudeRef"))
        if lat is not None and lon is not None:
            meta["GPSDecimal"] = f"{lat:.6f}, {lon:.6f}"
            meta["GPSMapsLink"] = f"https://www.google.com/maps?q={lat:.6f},{lon:.6f}"
    return meta


def _dms_to_decimal(dms, ref):
    if not isinstance(dms, (list, tuple)) or len(dms) != 3:
        return None
    dec = dms[0] + dms[1] / 60 + dms[2] / 3600
    if str(ref).upper() in ("S", "W"):
        dec = -dec
    return dec


def parse_png_text(path):
    with open(path, "rb") as fh:
        data = fh.read()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        return None
    out, pos = {}, 8
    while pos + 8 < len(data):
        try:
            length = struct.unpack(">I", data[pos:pos + 4])[0]
            ctype = data[pos + 4:pos + 8]
            chunk = data[pos + 8:pos + 8 + length]
        except struct.error:
            break
        if ctype == b"tEXt" and b"\x00" in chunk:
            k, v = chunk.split(b"\x00", 1)
            out[k.decode("latin1")] = v.decode("latin1", "replace")
        elif ctype == b"iTXt" and b"\x00" in chunk:
            k = chunk.split(b"\x00", 1)[0]
            out[k.decode("latin1")] = "(compressed iTXt present)"
        elif ctype == b"IEND":
            break
        pos += 12 + length
    return out


def run(args):
    from ..utils import emit_json, print_kv, ok, info

    path = args.image
    if not os.path.isfile(path):
        raise SystemExit(f"Not a file: {path}")
    with open(path, "rb") as fh:
        head = fh.read(16)

    if head.startswith(b"\xFF\xD8\xFF"):
        info("JPEG detected - parsing EXIF ...")
        meta = parse_jpeg_exif(path)
        kind = "JPEG/EXIF"
    elif head.startswith(b"\x89PNG"):
        info("PNG detected - parsing text chunks ...")
        meta = parse_png_text(path)
        kind = "PNG text chunks"
    else:
        warn("Not a JPEG or PNG - no metadata parser available for this format")
        return

    if args.json or args.output:
        emit_json({"file": path, "format": kind, "metadata": meta}, args.output)
        return

    if not meta:
        print("\n  No embedded metadata found.")
    else:
        print_kv(f"Metadata ({kind}): {path}", meta)
    ok("Metadata extraction complete.")
