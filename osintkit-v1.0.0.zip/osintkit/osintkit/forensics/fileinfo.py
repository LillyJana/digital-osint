"""File identification: magic bytes, entropy, basic structure checks.

Dependency-free signature table covering common evidence formats.
"""

import math
import os
import struct
import zipfile

from ..utils import human_size, info, warn

SIGNATURES = [
    (b"\xFF\xD8\xFF", "JPEG image"),
    (b"\x89PNG\r\n\x1a\n", "PNG image"),
    (b"GIF87a", "GIF image"), (b"GIF89a", "GIF image"),
    (b"%PDF-", "PDF document"),
    (b"PK\x03\x04", "ZIP archive (docx/xlsx/apk/jar/...)"),
    (b"PK\x05\x06", "ZIP archive (empty)"),
    (b"PK\x07\x08", "ZIP archive (spanned)"),
    (b"Rar!\x1a\x07\x00", "RAR archive v4"),
    (b"Rar!\x1a\x07\x01\x00", "RAR archive v5"),
    (b"\x1f\x8b\x08", "GZIP archive"),
    (b"BZh", "BZIP2 archive"),
    (b"\x37\x7A\xBC\xAF\x27\x1C", "7-Zip archive"),
    (b"\x75\x73\x74\x61\x72", "TAR archive"),
    (b"MZ", "Windows executable (PE)"),
    (b"\x7fELF", "ELF executable"),
    (b"\xca\xfe\xba\xbe", "Mach-O binary"),
    (b"\xfe\xed\xfa\xce", "Mach-O binary"),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "OLE compound document (doc/xls/...)"),
    (b"%!PS", "PostScript"),
    (b"II*\x00", "TIFF image (little-endian)"),
    (b"MM\x00*", "TIFF image (big-endian)"),
    (b"BM", "BMP image"),
    (b"RIFF", "RIFF container (WAV/AVI/WebP - check further)"),
    (b"\x00\x00\x01\x00", "ICO icon"),
    (b"fLaC", "FLAC audio"),
    (b"OggS", "OGG container"),
    (b"ID3", "MP3 audio (ID3)"),
    (b"\xff\xfb", "MP3 audio (frame sync)"),
    (b"SQLite format 3\x00", "SQLite database"),
    (b"\x53\x51\x4c\x69\x74\x65", "SQLite database"),
    (b"\x00\x01\x00\x00\x00", "PST/OST? (check)"),
    (b"!<arch>", "Unix ar archive"),
    (b"\xed\xab\xee\xdb", "RPM package"),
    (b"\x4d\x53\x43\x46", "CAB archive"),
    (b"\x50\x4b\x03\x04\x14\x00\x06\x00", "JAR/APK (zip variant)"),
    (b"\x1a\x45\xdf\xa3", "Matroska/WebM video"),
    (b"\x00\x00\x00\x18ftyp", "MP4/MOV (ftyp box)"),
    (b"\x00\x00\x00\x20ftyp", "MP4/MOV (ftyp box)"),
    (b"FLV\x01", "FLV video"),
    (b"\x30\x26\xb2\x75\x8e\x66\xcf\x11", "WMV/ASF video"),
    (b"-----BEGIN", "PEM certificate/key"),
    (b"\x30\x82", "DER certificate (probable)"),
]


def identify(path):
    with open(path, "rb") as fh:
        head = fh.read(64)
    matches = [label for sig, label in SIGNATURES if head.startswith(sig)]
    # Extra checks needing offsets
    if head[4:8] == b"ftyp" and not matches:
        matches.append("MP4/MOV video (ftyp)")
    if head.startswith(b"RIFF") and len(head) >= 12:
        matches.append(f"RIFF/{head[8:12].decode('ascii', 'replace').strip(chr(0))}")
    texty = all(c in b"\t\n\r" or 32 <= c < 127 for c in head[:64] if head)
    return matches, texty


def shannon_entropy(path, sample=65536):
    counts = [0] * 256
    total = 0
    with open(path, "rb") as fh:
        data = fh.read(sample)
    for byte in data:
        counts[byte] += 1
        total += 1
    if not total:
        return 0.0
    entropy = 0.0
    for c in counts:
        if c:
            p = c / total
            entropy -= p * math.log2(p)
    return entropy


def pe_info(path):
    """Minimal PE header parse: machine type, timestamp, sections."""
    with open(path, "rb") as fh:
        data = fh.read(4096)
    try:
        e_lfanew = struct.unpack("<I", data[0x3C:0x40])[0]
        if data[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
            return None
        machine, nsec, timestamp = struct.unpack("<HHI", data[e_lfanew + 4:e_lfanew + 12])
        machines = {0x014C: "x86", 0x8664: "x86-64", 0x01C0: "ARM", 0xAA64: "ARM64"}
        import datetime
        ts = datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc)
        return {"machine": machines.get(machine, hex(machine)),
                "sections": nsec, "compile_time_utc": ts.isoformat()}
    except (struct.error, IndexError, OSError, OverflowError, ValueError):
        return None


def zip_listing(path):
    try:
        with zipfile.ZipFile(path) as zf:
            bad = zf.testzip()
            return [i.filename for i in zf.infolist()][:50], bad
    except zipfile.BadZipFile:
        return None, "not a valid zip"


def run(args):
    from ..utils import emit_json, print_kv, ok

    path = args.file
    if not os.path.isfile(path):
        raise SystemExit(f"Not a file: {path}")
    size = os.path.getsize(path)
    matches, looks_text = identify(path)
    entropy = shannon_entropy(path)

    result = {"file": path, "size": size, "human_size": human_size(size),
              "magic_matches": matches, "looks_like_text": looks_text,
              "entropy_bits_per_byte": round(entropy, 3),
              "likely_packed_or_encrypted": entropy > 7.5 and not looks_text,
              "pe": None, "zip_contents": None}

    if any("PE" in m for m in matches):
        result["pe"] = pe_info(path)
    if any("ZIP" in m for m in matches):
        names, bad = zip_listing(path)
        result["zip_contents"] = {"entries": names, "corrupt_entry": bad}

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print_kv(f"File: {path}", {
        "Size": f"{size} bytes ({human_size(size)})",
        "Magic": "; ".join(matches) if matches else "unknown",
        "Looks like text": looks_text,
        "Entropy": f"{entropy:.3f} bits/byte",
        "Packed/encrypted?": result["likely_packed_or_encrypted"],
    })
    if result["pe"]:
        print_kv("PE header", result["pe"])
    if result["zip_contents"] and result["zip_contents"]["entries"]:
        print(f"\n  ZIP entries (first 50):")
        for n in result["zip_contents"]["entries"]:
            print(f"    - {n}")
        if result["zip_contents"]["corrupt_entry"]:
            warn(f"Corrupt entry: {result['zip_contents']['corrupt_entry']}")
    if entropy > 7.5 and not looks_text:
        info("High entropy suggests packing, encryption, or compression.")
    ok("File identification complete.")
