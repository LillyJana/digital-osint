"""File hashing: MD5/SHA-1/SHA-256/SHA-512, verification against hash lists."""

import hashlib
import os

from ..utils import chunked, info, ok, warn

ALGOS = ("md5", "sha1", "sha256", "sha512")


def hash_file(path, algos=ALGOS):
    digests = {a: hashlib.new(a) for a in algos}
    total = 0
    for chunk in chunked(path):
        total += len(chunk)
        for h in digests.values():
            h.update(chunk)
    return {a: h.hexdigest() for a, h in digests.items()}, total


def parse_hashlist(path):
    """Parse 'hash  filename' or bare-hash lines into {hash: filename}."""
    entries = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            digest = parts[0].lower()
            fname = parts[1].lstrip("*") if len(parts) > 1 else None
            entries[digest] = fname
    return entries


def run(args):
    from ..utils import emit_json

    if args.verify:
        info(f"Verifying files against {args.verify} ...")
        expected = parse_hashlist(args.verify)
        algo = {32: "md5", 40: "sha1", 64: "sha256", 128: "sha512"}
        mismatches = 0
        for path in args.files:
            if not os.path.isfile(path):
                warn(f"not a file: {path}")
                continue
            digests, _ = hash_file(path)
            hit = False
            for digest, fname in expected.items():
                want_algo = algo.get(len(digest))
                if want_algo and digests.get(want_algo) == digest:
                    if fname and os.path.basename(path) != os.path.basename(fname):
                        continue
                    hit = True
                    break
            status = "MATCH" if hit else "NO MATCH"
            print(f"  [{status}] {path}")
            mismatches += not hit
        if mismatches:
            warn(f"{mismatches} file(s) did not match the hash list")
        else:
            ok("All files verified.")
        return

    results = []
    for path in args.files:
        if not os.path.isfile(path):
            warn(f"not a file: {path}")
            continue
        digests, size = hash_file(path, args.algo or ALGOS)
        results.append({"file": path, "size": size, "hashes": digests})

    if args.json or args.output:
        emit_json(results, args.output)
        return

    for r in results:
        print(f"\n  {r['file']} ({r['size']} bytes)")
        for algo, digest in r["hashes"].items():
            print(f"    {algo:8} {digest}")

    if args.write:
        out = args.write
        with open(out, "w", encoding="utf-8") as fh:
            for r in results:
                algo = (args.algo or ["sha256"])[0]
                fh.write(f"{r['hashes'][algo]}  {r['file']}\n")
        ok(f"Hash list written to {out}")
