"""Log analysis: extract IPs, URLs, errors and brute-force patterns.

Works on plain-text logs (syslog, auth.log, web access logs, ...).
"""

import collections
import os
import re

from ..utils import ok, warn

IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
URL_RE = re.compile(r"https?://[^\s'\"<>\\]+")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
FAIL_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in (
        r"failed password", r"authentication failure", r"invalid user",
        r"failed login", r"unauthorized", r"access denied",
        r"brute", r"too many", r"blocked",
    )
]
ERROR_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in (
        r"\berror\b", r"\bcritical\b", r"exception", r"traceback",
        r"segfault", r"kernel panic", r"denied",
    )
]


def analyze(path, top=20):
    ips = collections.Counter()
    urls = collections.Counter()
    emails = set()
    failed_logins = collections.Counter()
    errors = []
    total = 0
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            total += 1
            for m in IP_RE.findall(line):
                ips[m] += 1
            for m in URL_RE.findall(line):
                urls[m] += 1
            for m in EMAIL_RE.findall(line):
                emails.add(m)
            if any(p.search(line) for p in FAIL_PATTERNS):
                for m in IP_RE.findall(line):
                    failed_logins[m] += 1
            if any(p.search(line) for p in ERROR_PATTERNS):
                errors.append(line.strip()[:200])
    return {
        "file": path, "lines": total,
        "top_ips": ips.most_common(top),
        "top_urls": urls.most_common(top),
        "emails": sorted(emails)[:100],
        "failed_login_sources": failed_logins.most_common(top),
        "error_samples": errors[:50],
        "error_count": len(errors),
    }


def run(args):
    from ..utils import emit_json

    if not os.path.isfile(args.logfile):
        raise SystemExit(f"Not a file: {args.logfile}")
    result = analyze(args.logfile, top=args.top)

    if args.json or args.output:
        result["top_ips"] = [list(x) for x in result["top_ips"]]
        result["top_urls"] = [list(x) for x in result["top_urls"]]
        result["failed_login_sources"] = [list(x) for x in result["failed_login_sources"]]
        emit_json(result, args.output)
        return

    print(f"\n  Log: {result['file']} ({result['lines']} lines)")
    print(f"\n  Top {args.top} source IPs:")
    for ip, count in result["top_ips"]:
        print(f"    {count:8}  {ip}")
    if result["failed_login_sources"]:
        print(f"\n  Possible brute-force sources (failed auth by IP):")
        for ip, count in result["failed_login_sources"]:
            flag = "  <-- review" if count >= 10 else ""
            print(f"    {count:8}  {ip}{flag}")
    else:
        print("\n  No failed-authentication patterns found.")
    if result["top_urls"]:
        print(f"\n  Top URLs referenced:")
        for url, count in result["top_urls"]:
            print(f"    {count:8}  {url[:100]}")
    if result["emails"]:
        print(f"\n  Email addresses seen ({len(result['emails'])}):")
        for e in result["emails"][:20]:
            print(f"    {e}")
    print(f"\n  Error/critical lines: {result['error_count']}")
    for line in result["error_samples"][:10]:
        print(f"    {line}")
    if not result["failed_login_sources"] and result["error_count"] == 0:
        warn("Nothing suspicious found by these heuristics.")
    ok("Log analysis complete.")
