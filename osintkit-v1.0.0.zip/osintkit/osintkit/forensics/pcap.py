"""PCAP triage: parse capture files without external dependencies.

Reports packet counts by protocol, top talkers, DNS queries, HTTP hosts
and flags unusually large flows. Full dissection is out of scope -
pair this with Wireshark for deep dives.
"""

import collections
import datetime
import os
import struct

from ..utils import ok, warn

DLT_EN10MB = 1
ETHERTYPES = {0x0800: "IPv4", 0x86DD: "IPv6", 0x0806: "ARP"}
IP_PROTOS = {1: "ICMP", 6: "TCP", 17: "UDP", 2: "IGMP"}


def _ip_str(raw):
    return ".".join(str(b) for b in raw)


def parse_pcap(path):
    with open(path, "rb") as fh:
        data = fh.read()
    if len(data) < 24:
        raise ValueError("file too small to be a pcap")
    magic = data[:4]
    if magic == b"\xd4\xc3\xb2\xa1":
        endian = "<"
    elif magic == b"\xa1\xb2\xc3\xd4":
        endian = ">"
    else:
        raise ValueError("not a classic pcap (pcapng not supported in triage mode)")
    _ver_maj, _ver_min, _tz, _sig, _snaplen, network = struct.unpack(endian + "HHIIII", data[4:24])
    if network != DLT_EN10MB:
        warn(f"link type {network} is not Ethernet - L2 parsing may be off")

    stats = {
        "packets": 0, "bytes": 0,
        "protocols": collections.Counter(),
        "talkers": collections.Counter(),
        "flows": collections.Counter(),
        "dns_queries": collections.Counter(),
        "http_hosts": collections.Counter(),
        "ports": collections.Counter(),
        "start": None, "end": None,
    }
    pos = 24
    while pos + 16 <= len(data):
        ts_sec, ts_usec, incl, _orig = struct.unpack(endian + "IIII", data[pos:pos + 16])
        pos += 16
        pkt = data[pos:pos + incl]
        pos += incl
        if len(pkt) < 14:
            continue
        ts = datetime.datetime.fromtimestamp(ts_sec + ts_usec / 1e6,
                                             datetime.timezone.utc)
        if stats["start"] is None:
            stats["start"] = ts
        stats["end"] = ts
        stats["packets"] += 1
        stats["bytes"] += incl

        ethertype = struct.unpack(">H", pkt[12:14])[0]
        stats["protocols"][ETHERTYPES.get(ethertype, hex(ethertype))] += 1
        if ethertype != 0x0800 or len(pkt) < 34:
            continue
        ihl = (pkt[14] & 0x0F) * 4
        proto = pkt[23]
        src, dst = _ip_str(pkt[26:30]), _ip_str(pkt[30:34])
        pname = IP_PROTOS.get(proto, f"IP-{proto}")
        stats["protocols"][pname] += 1
        stats["talkers"][src] += 1
        stats["talkers"][dst] += 1
        ip_end = 14 + ihl
        if proto in (6, 17) and len(pkt) >= ip_end + 4:  # TCP/UDP
            sport, dport = struct.unpack(">HH", pkt[ip_end:ip_end + 4])
            stats["ports"][dport] += 1
            stats["flows"][(src, sport, dst, dport, pname)] += incl
            payload = pkt[ip_end + (20 if proto == 6 else 8):]
            if proto == 17 and (sport == 53 or dport == 53):
                qname = _dns_qname(payload)
                if qname:
                    stats["dns_queries"][qname] += 1
            if proto == 6 and dport == 80 and payload.startswith(b"GET "):
                host = _http_host(payload)
                if host:
                    stats["http_hosts"][host] += 1
    return stats


def _dns_qname(payload):
    try:
        if len(payload) < 12:
            return None
        qdcount = struct.unpack(">H", payload[4:6])[0]
        if qdcount != 1:
            return None
        pos, labels = 12, []
        while pos < len(payload) and payload[pos] != 0:
            ln = payload[pos]
            if ln & 0xC0:
                break
            labels.append(payload[pos + 1:pos + 1 + ln].decode("ascii", "replace"))
            pos += 1 + ln
        return ".".join(labels) if labels else None
    except (IndexError, struct.error, UnicodeDecodeError):
        return None


def _http_host(payload):
    try:
        text = payload[:2048].decode("latin1")
        for line in text.split("\r\n"):
            if line.lower().startswith("host:"):
                return line.split(":", 1)[1].strip()
    except Exception:  # noqa: BLE001
        pass
    return None


def run(args):
    from ..utils import emit_json

    if not os.path.isfile(args.pcap):
        raise SystemExit(f"Not a file: {args.pcap}")
    try:
        s = parse_pcap(args.pcap)
    except ValueError as exc:
        raise SystemExit(f"Cannot parse: {exc}")

    top = args.top
    serializable = {
        "file": args.pcap, "packets": s["packets"], "bytes": s["bytes"],
        "start_utc": s["start"].isoformat() if s["start"] else None,
        "end_utc": s["end"].isoformat() if s["end"] else None,
        "protocols": dict(s["protocols"]),
        "top_talkers": s["talkers"].most_common(top),
        "top_ports": s["ports"].most_common(top),
        "top_dns_queries": s["dns_queries"].most_common(top),
        "top_http_hosts": s["http_hosts"].most_common(top),
        "largest_flows_bytes": [
            {"src": f[0], "sport": f[1], "dst": f[2], "dport": f[3],
             "proto": f[4], "bytes": b}
            for f, b in s["flows"].most_common(10)
        ],
    }

    if args.json or args.output:
        serializable["top_talkers"] = [list(x) for x in serializable["top_talkers"]]
        serializable["top_ports"] = [list(x) for x in serializable["top_ports"]]
        serializable["top_dns_queries"] = [list(x) for x in serializable["top_dns_queries"]]
        serializable["top_http_hosts"] = [list(x) for x in serializable["top_http_hosts"]]
        emit_json(serializable, args.output)
        return

    print(f"\n  Capture: {args.pcap}")
    print(f"  Packets: {s['packets']:,}   Bytes: {s['bytes']:,}")
    print(f"  Window:  {serializable['start_utc']} -> {serializable['end_utc']}")
    print("\n  Protocols:")
    for proto, count in s["protocols"].most_common():
        print(f"    {count:8,}  {proto}")
    print(f"\n  Top {top} talkers:")
    for ip, count in s["talkers"].most_common(top):
        print(f"    {count:8,}  {ip}")
    print(f"\n  Top {top} destination ports:")
    for port, count in s["ports"].most_common(top):
        print(f"    {count:8,}  {port}")
    if s["dns_queries"]:
        print(f"\n  Top DNS queries:")
        for q, count in s["dns_queries"].most_common(top):
            print(f"    {count:8,}  {q}")
    if s["http_hosts"]:
        print(f"\n  HTTP hosts:")
        for h, count in s["http_hosts"].most_common(top):
            print(f"    {count:8,}  {h}")
    print("\n  Largest flows (bytes):")
    for f in serializable["largest_flows_bytes"]:
        print(f"    {f['bytes']:10,}  {f['src']}:{f['sport']} -> {f['dst']}:{f['dport']} ({f['proto']})")
    ok("PCAP triage complete.")
