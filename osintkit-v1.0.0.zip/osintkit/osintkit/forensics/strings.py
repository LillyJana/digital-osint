"""Printable-string extraction from binary files (like `strings`)."""

import os
import re

from ..utils import ok, warn

URL_RE = re.compile(rb"https?://[^\s'\"<>\\]+")
EMAIL_RE = re.compile(rb"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
IP_RE = re.compile(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b")
WINPATH_RE = re.compile(rb"[A-Za-z]:\\[^\s'\"<>|]+")
UNIXPATH_RE = re.compile(rb"/(?:home|root|tmp|var|etc|usr|opt|mnt)/[^\s'\"<>|]+")


def extract_strings(path, min_len=4, encoding="ascii"):
    """Yield printable strings of at least min_len from a file."""
    if encoding == "utf16":
        pattern = re.compile(rb"(?:[\x20-\x7e]\x00){%d,}" % min_len)
    else:
        pattern = re.compile(rb"[\x20-\x7e]{%d,}" % min_len)
    with open(path, "rb") as fh:
        data = fh.read()
    for match in pattern.finditer(data):
        raw = match.group()
        if encoding == "utf16":
            yield raw.decode("utf-16-le", "replace")
        else:
            yield raw.decode("ascii", "replace")


def interesting(strings_iter):
    """Pull out IOC-ish strings: URLs, emails, IPs, paths."""
    found = {"urls": set(), "emails": set(), "ips": set(), "paths": set()}
    for s in strings_iter:
        b = s.encode("ascii", "replace")
        for m in URL_RE.findall(b):
            found["urls"].add(m.decode())
        for m in EMAIL_RE.findall(b):
            found["emails"].add(m.decode())
        for m in IP_RE.findall(b):
            found["ips"].add(m.decode())
        for m in WINPATH_RE.findall(b):
            found["paths"].add(m.decode())
        for m in UNIXPATH_RE.findall(b):
            found["paths"].add(m.decode())
    return {k: sorted(v) for k, v in found.items()}


def run(args):
    from ..utils import emit_json

    path = args.file
    if not os.path.isfile(path):
        raise SystemExit(f"Not a file: {path}")

    encodings = ["ascii", "utf16"] if args.unicode else ["ascii"]
    all_strings = []
    for enc in encodings:
        all_strings.extend(extract_strings(path, args.min_length, enc))
    # De-duplicate while preserving order
    seen, uniq = set(), []
    for s in all_strings:
        if s not in seen:
            seen.add(s)
            uniq.append(s)

    iocs = interesting(iter(uniq)) if (args.iocs or args.iocs_only) else None

    if args.json or args.output:
        emit_json({"file": path, "string_count": len(uniq),
                   "strings": uniq if not args.iocs_only else [],
                   "iocs": iocs}, args.output)
        return

    if args.iocs_only:
        if iocs:
            for kind, values in iocs.items():
                if values:
                    print(f"\n  {kind.upper()} ({len(values)}):")
                    for v in values[:100]:
                        print(f"    {v}")
        ok(f"Extracted {len(uniq)} strings, showing IOCs only.")
        return

    for s in uniq[: args.limit]:
        print(s)
    if len(uniq) > args.limit:
        print(f"\n  ... and {len(uniq) - args.limit} more (use --limit 0 for all, "
              f"or --json to dump)")
    if iocs:
        print("\n  --- Indicators of compromise ---")
        for kind, values in iocs.items():
            if values:
                print(f"  {kind}: {len(values)} (see --iocs-only for the list)")
    ok(f"Extracted {len(uniq)} strings.")
