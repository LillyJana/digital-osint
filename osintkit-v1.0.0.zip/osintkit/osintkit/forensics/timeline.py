"""Filesystem timeline builder: walk a directory and emit a CSV timeline.

Useful for "what changed, and when" analysis. Captures mtime/atime/ctime,
size, and hashes for each file.
"""

import csv
import datetime
import hashlib
import os

from ..utils import info, ok, warn


def build_timeline(root, hash_files=False):
    rows = []
    for dirpath, dirnames, filenames in os.walk(root):
        # Skip volatile pseudo-filesystems when pointed at /
        dirnames[:] = [d for d in dirnames if d not in ("proc", "sys", "dev")]
        for name in filenames:
            path = os.path.join(dirpath, name)
            try:
                st = os.lstat(path)
            except OSError:
                continue
            row = {
                "path": path,
                "size": st.st_size,
                "mtime": _ts(st.st_mtime),
                "atime": _ts(st.st_atime),
                "ctime": _ts(st.st_ctime),
                "sha256": "",
            }
            if hash_files and st.st_size < 100 * 1024 * 1024:
                try:
                    h = hashlib.sha256()
                    with open(path, "rb") as fh:
                        for chunk in iter(lambda: fh.read(65536), b""):
                            h.update(chunk)
                    row["sha256"] = h.hexdigest()
                except OSError:
                    pass
            rows.append(row)
    rows.sort(key=lambda r: r["mtime"])
    return rows


def _ts(epoch):
    return datetime.datetime.fromtimestamp(
        epoch, datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def run(args):
    root = args.directory
    if not os.path.isdir(root):
        raise SystemExit(f"Not a directory: {root}")
    info(f"Walking {root} ...")
    rows = build_timeline(root, hash_files=args.hash)
    info(f"Collected {len(rows)} file records")

    if args.since:
        rows = [r for r in rows if r["mtime"] >= args.since]
        info(f"{len(rows)} records on/after {args.since}")

    out = args.output or "timeline.csv"
    with open(out, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["mtime", "atime", "ctime",
                                                "size", "sha256", "path"])
        writer.writeheader()
        writer.writerows(rows)
    ok(f"Timeline written to {out} ({len(rows)} rows)")

    if args.tail:
        print("\n  Most recent entries:")
        for r in rows[-args.tail:]:
            print(f"    {r['mtime']}  {r['path']}")
