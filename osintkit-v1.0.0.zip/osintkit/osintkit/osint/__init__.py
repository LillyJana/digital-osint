"""OSINT subpackage: passive reconnaissance helpers."""
