"""Domain reconnaissance: DNS records, subdomains, WHOIS.

Uses a dependency-free DNS client (UDP) plus free passive sources
(crt.sh) and a raw WHOIS lookup over TCP/43.
"""

import random
import socket
import struct
import time

from ..utils import http_get, info, warn

QTYPE = {
    "A": 1, "AAAA": 28, "CNAME": 5, "MX": 15, "NS": 2,
    "TXT": 16, "SOA": 6, "SRV": 33, "CAA": 257, "PTR": 12,
}
DNS_SERVERS = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]


def _encode_name(name):
    parts = name.rstrip(".").split(".")
    out = b""
    for part in parts:
        encoded = part.encode("idna")
        out += bytes([len(encoded)]) + encoded
    return out + b"\x00"


def _decode_name(data, offset):
    labels, jumped, original = [], False, offset
    while True:
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0 == 0xC0:  # compression pointer
            pointer = struct.unpack(">H", data[offset:offset + 2])[0] & 0x3FFF
            if not jumped:
                original = offset + 2
            offset = pointer
            jumped = True
            continue
        offset += 1
        labels.append(data[offset:offset + length].decode("utf-8", "replace"))
        offset += length
    return ".".join(labels), (original if jumped else offset)


def _rdata_to_text(rtype, rdata, data, rdata_offset):
    try:
        if rtype in (2, 5, 12):  # NS, CNAME, PTR
            name, _ = _decode_name(data, rdata_offset)
            return name
        if rtype == 1:  # A
            return socket.inet_ntoa(rdata)
        if rtype == 28:  # AAAA
            return socket.inet_ntop(socket.AF_INET6, rdata)
        if rtype == 15:  # MX
            pref = struct.unpack(">H", rdata[:2])[0]
            host, _ = _decode_name(data, rdata_offset + 2)
            return f"{pref} {host}"
        if rtype == 16:  # TXT
            texts, i = [], 0
            while i < len(rdata):
                ln = rdata[i]
                texts.append(rdata[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                i += 1 + ln
            return " ".join(texts)
        if rtype == 6:  # SOA
            mname, off = _decode_name(data, rdata_offset)
            rname, off = _decode_name(data, off)
            serial = struct.unpack(">I", data[off:off + 4])[0]
            return f"{mname} {rname} serial={serial}"
        if rtype == 257:  # CAA
            flag, tag_len = rdata[0], rdata[1]
            tag = rdata[2:2 + tag_len].decode()
            value = rdata[2 + tag_len:].decode("utf-8", "replace")
            return f"flag={flag} {tag} {value}"
    except Exception:  # noqa: BLE001 - best effort decode
        pass
    return rdata.hex()


def dns_query(name, qtype="A", timeout=5):
    """Query DNS directly, falling back to DNS-over-HTTPS if UDP is blocked."""
    answers = _dns_query_udp(name, qtype, timeout)
    if answers:
        return answers
    return _dns_query_doh(name, qtype, timeout)


def _dns_query_doh(name, qtype="A", timeout=10):
    """DNS-over-HTTPS fallback (Cloudflare), returns list of answer strings."""
    import json as _json
    try:
        status, _, body = http_get(
            "https://cloudflare-dns.com/dns-query",
            params={"name": name, "type": qtype.upper()},
            headers={"Accept": "application/dns-json"},
            timeout=timeout)
    except RuntimeError:
        return []
    if status != 200:
        return []
    try:
        data = _json.loads(body.decode("utf-8", "replace"))
    except ValueError:
        return []
    return [a.get("data", "") for a in data.get("Answer", []) if a.get("data")]


def _dns_query_udp(name, qtype="A", timeout=5):
    """Query DNS directly. Returns list of answer strings."""
    qid = random.randint(0, 65535)
    header = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)
    question = _encode_name(name) + struct.pack(">HH", QTYPE[qtype.upper()], 1)
    packet = header + question
    answers = []
    for server in DNS_SERVERS:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(packet, (server, 53))
            data, _ = sock.recvfrom(512)
        except (socket.timeout, OSError):
            continue
        finally:
            sock.close()
        if len(data) < 12 or struct.unpack(">H", data[:2])[0] != qid:
            continue
        ancount = struct.unpack(">H", data[6:8])[0]
        offset = len(packet)
        try:
            for _ in range(ancount):
                _, offset = _decode_name(data, offset)
                rtype, _, _, rdlen = struct.unpack(">HHIH", data[offset:offset + 10])
                rdata_off = offset + 10
                answers.append(_rdata_to_text(rtype, data[rdata_off:rdata_off + rdlen],
                                              data, rdata_off))
                offset = rdata_off + rdlen
        except (struct.error, IndexError):
            continue
        if answers:
            return answers
    return answers


def whois_lookup(domain, timeout=10):
    """Raw WHOIS lookup over TCP/43, following the registrar referral."""
    def _query(server, query):
        sock = socket.create_connection((server, 43), timeout=timeout)
        try:
            sock.sendall((query + "\r\n").encode())
            chunks = []
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                chunks.append(chunk)
        finally:
            sock.close()
        return b"".join(chunks).decode("utf-8", "replace", )

    tld = domain.rsplit(".", 1)[-1].lower()
    iana = _query("whois.iana.org", tld)
    referral = None
    for line in iana.splitlines():
        if line.lower().startswith("whois:"):
            referral = line.split(":", 1)[1].strip()
            break
    server = referral or "whois.verisign-grs.com"
    try:
        return _query(server, domain)
    except OSError as exc:
        return f"WHOIS lookup failed: {exc}"


def crtsh_subdomains(domain, timeout=25):
    """Subdomain enumeration via crt.sh (Certificate Transparency)."""
    status, _, body = http_get(
        "https://crt.sh/", params={"q": f"%.{domain}", "output": "json"}, timeout=timeout)
    if status != 200:
        raise RuntimeError(f"crt.sh returned HTTP {status}")
    import json as _json
    subs = set()
    for entry in _json.loads(body.decode("utf-8", "replace")):
        for name in entry.get("name_value", "").splitlines():
            name = name.strip().lower().rstrip(".")
            if name and not name.startswith("*."):
                subs.add(name)
            elif name.startswith("*."):
                subs.add(name[2:])
    return sorted(subs)


def reverse_dns(ip, timeout=5):
    try:
        return socket.gethostbyaddr(ip)[0]
    except (socket.herror, socket.gaierror, OSError):
        return None


def run(args):
    from ..utils import emit_json, print_kv, print_list, ok

    domain = args.domain.lower().strip()
    result = {"domain": domain, "dns": {}, "whois": None, "subdomains": []}

    info(f"Resolving DNS records for {domain} ...")
    for rtype in ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CAA"]:
        answers = dns_query(domain, rtype)
        result["dns"][rtype] = answers
        time.sleep(0.2)

    if args.whois:
        info("Querying WHOIS ...")
        result["whois"] = whois_lookup(domain)

    if args.subdomains:
        info("Enumerating subdomains via crt.sh ...")
        try:
            result["subdomains"] = crtsh_subdomains(domain)
        except RuntimeError as exc:
            warn(str(exc))

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print_kv(f"DNS records: {domain}", {k: v for k, v in result["dns"].items() if v})
    empty = [k for k, v in result["dns"].items() if not v]
    if empty:
        print(f"\n  (no records: {', '.join(empty)})")
    if result["subdomains"]:
        print_list("Subdomains (crt.sh)", result["subdomains"])
    if result["whois"]:
        print("\n--- WHOIS ---")
        print(result["whois"][:4000])
    ok("Domain reconnaissance complete.")
