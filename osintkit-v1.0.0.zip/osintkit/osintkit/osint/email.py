"""Email OSINT: syntax validation, MX check, Gravatar, breach lookup.

HaveIBeenPwned requires an API key (config set HIBP_API_KEY <key>).
"""

import hashlib
import json
import re
import socket

from .. import config
from ..utils import http_get, info, warn

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def validate_syntax(email):
    return bool(EMAIL_RE.match(email.strip()))


def check_mx(domain, timeout=5):
    """Best-effort MX check using the local resolver."""
    try:
        answers = socket.getaddrinfo(domain, 25, type=socket.SOCK_STREAM)
        return bool(answers)
    except socket.gaierror:
        return False


def gravatar_exists(email, timeout=10):
    digest = hashlib.md5(email.strip().lower().encode()).hexdigest()
    status, _, _ = http_get(f"https://www.gravatar.com/avatar/{digest}",
                            params={"d": "404", "s": "1"}, timeout=timeout)
    return status == 200, digest


def hibp_breaches(email, timeout=20):
    key = config.get_key("HIBP_API_KEY")
    if not key:
        return None
    account = email.strip()
    status, _, body = http_get(
        f"https://haveibeenpwned.com/api/v3/breachedaccount/{account}",
        params={"truncateResponse": "false"},
        headers={"hibp-api-key": key, "User-Agent": "OSINTKit"},
        timeout=timeout)
    if status == 404:
        return []
    if status == 401:
        raise RuntimeError("HaveIBeenPwned: invalid API key")
    if status == 429:
        raise RuntimeError("HaveIBeenPwned: rate limit reached")
    if status != 200:
        raise RuntimeError(f"HaveIBeenPwned returned HTTP {status}")
    return json.loads(body.decode("utf-8", "replace"))


def run(args):
    from ..utils import emit_json, print_kv, ok

    email = args.email.strip()
    result = {"email": email, "syntax_valid": validate_syntax(email),
              "domain": email.rsplit("@", 1)[-1] if "@" in email else None,
              "mx_reachable": None, "gravatar": None, "breaches": None}

    if result["syntax_valid"]:
        info("Checking mail exchanger ...")
        result["mx_reachable"] = check_mx(result["domain"])
        info("Checking Gravatar ...")
        try:
            exists, digest = gravatar_exists(email)
            result["gravatar"] = {"exists": exists, "hash": digest}
        except RuntimeError as exc:
            warn(str(exc))
        info("Checking HaveIBeenPwned ...")
        try:
            breaches = hibp_breaches(email)
            if breaches is None:
                info("HaveIBeenPwned skipped (no API key configured)")
            else:
                result["breaches"] = [
                    {"name": b.get("Name"), "date": b.get("BreachDate"),
                     "data_classes": b.get("DataClasses"), "verified": b.get("IsVerified")}
                    for b in breaches
                ]
        except RuntimeError as exc:
            warn(str(exc))
    else:
        warn("Invalid email syntax - skipping live checks")

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print_kv(f"Email: {email}", {
        "Syntax valid": result["syntax_valid"],
        "Domain": result["domain"],
        "MX reachable": result["mx_reachable"],
        "Gravatar profile": (result["gravatar"] or {}).get("exists"),
    })
    if result["breaches"]:
        print(f"\n  Breaches found: {len(result['breaches'])}")
        for b in result["breaches"]:
            print(f"    - {b['name']} ({b['date']}) verified={b['verified']}")
            print(f"      exposed: {', '.join(b['data_classes'] or [])}")
    elif result["breaches"] == []:
        print("\n  No breaches found for this address.")
    ok("Email OSINT complete.")
