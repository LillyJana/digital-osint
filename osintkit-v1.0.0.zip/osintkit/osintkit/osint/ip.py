"""IP address intelligence: geolocation, reverse DNS, reputation.

Free sources work without keys; AbuseIPDB and Shodan enrich results
when their API keys are configured.
"""

import ipaddress
import json
import socket

from .. import config
from ..utils import http_get, info, warn


def geolocate(ip, timeout=15):
    """Free geolocation via ip-api.com (no key, rate-limited)."""
    status, _, body = http_get(f"http://ip-api.com/json/{ip}",
                               params={"fields": "status,message,country,countryCode,regionName,"
                                                 "city,zip,lat,lon,timezone,isp,org,as,asname,"
                                                 "reverse,mobile,proxy,hosting,query"},
                               timeout=timeout)
    if status != 200:
        raise RuntimeError(f"ip-api returned HTTP {status}")
    data = json.loads(body.decode("utf-8", "replace"))
    if data.get("status") != "success":
        raise RuntimeError(f"ip-api: {data.get('message', 'lookup failed')}")
    data.pop("status", None)
    return data


def abuseipdb_check(ip, timeout=15):
    key = config.get_key("ABUSEIPDB_API_KEY")
    if not key:
        return None
    status, _, body = http_get(
        "https://api.abuseipdb.com/api/v2/check",
        params={"ipAddress": ip, "maxAgeInDays": 90, "verbose": ""},
        headers={"Key": key, "Accept": "application/json"},
        timeout=timeout)
    if status == 401:
        raise RuntimeError("AbuseIPDB: invalid API key")
    if status == 429:
        raise RuntimeError("AbuseIPDB: rate limit reached")
    if status != 200:
        raise RuntimeError(f"AbuseIPDB returned HTTP {status}")
    return json.loads(body.decode("utf-8", "replace")).get("data", {})


def shodan_host(ip, timeout=20):
    key = config.get_key("SHODAN_API_KEY")
    if not key:
        return None
    status, _, body = http_get(f"https://api.shodan.io/shodan/host/{ip}",
                               params={"key": key}, timeout=timeout)
    if status == 401:
        raise RuntimeError("Shodan: invalid API key")
    if status == 404:
        return {"note": "No Shodan data for this host"}
    if status != 200:
        raise RuntimeError(f"Shodan returned HTTP {status}")
    data = json.loads(body.decode("utf-8", "replace"))
    return {
        "ip": data.get("ip_str"),
        "org": data.get("org"),
        "os": data.get("os"),
        "ports": data.get("ports"),
        "hostnames": data.get("hostnames"),
        "vulns": list((data.get("vulns") or {}).keys()),
        "last_update": data.get("last_update"),
    }


def run(args):
    from ..utils import emit_json, print_kv, ok

    target = args.ip.strip()
    try:
        parsed = ipaddress.ip_address(target)
    except ValueError:
        # Maybe a hostname - resolve it first.
        info(f"{target} is not an IP, resolving ...")
        try:
            target = socket.gethostbyname(target)
            parsed = ipaddress.ip_address(target)
            info(f"Resolved to {target}")
        except socket.gaierror:
            raise SystemExit(f"Cannot resolve {args.ip}")
    result = {"ip": str(parsed), "private": parsed.is_private,
              "geo": None, "reverse_dns": None,
              "abuseipdb": None, "shodan": None}

    try:
        rev = socket.gethostbyaddr(str(parsed))[0]
        result["reverse_dns"] = rev
    except (socket.herror, socket.gaierror, OSError):
        pass

    if not parsed.is_private:
        info("Geolocating ...")
        try:
            result["geo"] = geolocate(str(parsed))
        except RuntimeError as exc:
            warn(str(exc))
        info("Checking AbuseIPDB ...")
        try:
            result["abuseipdb"] = abuseipdb_check(str(parsed))
        except RuntimeError as exc:
            warn(str(exc))
        if result["abuseipdb"] is None and not config.get_key("ABUSEIPDB_API_KEY"):
            info("AbuseIPDB skipped (no API key configured)")
        info("Checking Shodan ...")
        try:
            result["shodan"] = shodan_host(str(parsed))
        except RuntimeError as exc:
            warn(str(exc))
        if result["shodan"] is None and not config.get_key("SHODAN_API_KEY"):
            info("Shodan skipped (no API key configured)")
    else:
        info("Private address - skipping external lookups")

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print_kv(f"IP: {result['ip']}",
             {"Private": result["private"], "Reverse DNS": result["reverse_dns"]})
    if result["geo"]:
        print_kv("Geolocation (ip-api.com)", result["geo"])
    if result["abuseipdb"]:
        d = result["abuseipdb"]
        print_kv("AbuseIPDB", {
            "Abuse confidence": f"{d.get('abuseConfidenceScore')}%",
            "Total reports": d.get("totalReports"),
            "Last reported": d.get("lastReportedAt"),
            "ISP": d.get("isp"), "Country": d.get("countryCode"),
        })
    if result["shodan"]:
        print_kv("Shodan", result["shodan"])
    ok("IP intelligence complete.")
