"""URL analysis: redirect chain, headers, reputation.

VirusTotal and urlscan.io enrich results when API keys are configured.
"""

import json
import urllib.parse

from .. import config
from ..utils import http_get, info, warn


def expand_url(url, timeout=15, max_hops=10):
    """Follow redirects manually, recording each hop."""
    chain = []
    current = url if "://" in url else "http://" + url
    for _ in range(max_hops):
        try:
            status, headers, _ = http_get(current, timeout=timeout)
        except RuntimeError as exc:
            chain.append({"url": current, "error": str(exc)})
            break
        chain.append({"url": current, "status": status,
                      "server": headers.get("Server"),
                      "content_type": headers.get("Content-Type")})
        if status in (301, 302, 303, 307, 308) and headers.get("Location"):
            current = urllib.parse.urljoin(current, headers["Location"])
            continue
        break
    return chain


def virustotal_url(url, timeout=20):
    key = config.get_key("VIRUSTOTAL_API_KEY")
    if not key:
        return None
    import base64
    url_id = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
    status, _, body = http_get(f"https://www.virustotal.com/api/v3/urls/{url_id}",
                               headers={"x-apikey": key}, timeout=timeout)
    if status == 401:
        raise RuntimeError("VirusTotal: invalid API key")
    if status == 404:
        return {"note": "URL not seen by VirusTotal"}
    if status != 200:
        raise RuntimeError(f"VirusTotal returned HTTP {status}")
    attrs = json.loads(body.decode("utf-8", "replace")).get("data", {}).get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})
    return {
        "reputation": attrs.get("reputation"),
        "categories": attrs.get("categories"),
        "malicious": stats.get("malicious"), "suspicious": stats.get("suspicious"),
        "harmless": stats.get("harmless"), "undetected": stats.get("undetected"),
        "last_analysis": attrs.get("last_analysis_date"),
        "title": attrs.get("title"),
    }


def urlscan_search(domain, timeout=20):
    key = config.get_key("URLSCAN_API_KEY")
    if not key:
        return None
    status, _, body = http_get("https://urlscan.io/api/v1/search/",
                               params={"q": f"domain:{domain}"},
                               headers={"API-Key": key} if key else {},
                               timeout=timeout)
    if status == 401:
        raise RuntimeError("urlscan.io: invalid API key")
    if status != 200:
        raise RuntimeError(f"urlscan.io returned HTTP {status}")
    data = json.loads(body.decode("utf-8", "replace"))
    out = []
    for r in data.get("results", [])[:10]:
        out.append({"url": r.get("page", {}).get("url"),
                    "scan": r.get("task", {}).get("url"),
                    "time": r.get("task", {}).get("time")})
    return {"total": data.get("total"), "recent": out}


def run(args):
    from ..utils import emit_json, print_kv, ok

    url = args.url.strip()
    parsed = urllib.parse.urlparse(url if "://" in url else "http://" + url)
    result = {"url": url, "domain": parsed.hostname,
              "redirect_chain": [], "virustotal": None, "urlscan": None}

    info("Tracing redirect chain ...")
    result["redirect_chain"] = expand_url(url)

    info("Checking VirusTotal ...")
    try:
        result["virustotal"] = virustotal_url(url)
    except RuntimeError as exc:
        warn(str(exc))
    if result["virustotal"] is None and not config.get_key("VIRUSTOTAL_API_KEY"):
        info("VirusTotal skipped (no API key configured)")

    if parsed.hostname:
        info("Searching urlscan.io ...")
        try:
            result["urlscan"] = urlscan_search(parsed.hostname)
        except RuntimeError as exc:
            warn(str(exc))
        if result["urlscan"] is None and not config.get_key("URLSCAN_API_KEY"):
            info("urlscan.io skipped (no API key configured)")

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print(f"\n  Redirect chain ({len(result['redirect_chain'])} hops):")
    for hop in result["redirect_chain"]:
        if "error" in hop:
            print(f"    ! {hop['url']} -> {hop['error']}")
        else:
            print(f"    [{hop['status']}] {hop['url']}")
            if hop.get("server"):
                print(f"           server: {hop['server']}")
    if result["virustotal"] and "note" not in result["virustotal"]:
        print_kv("VirusTotal", result["virustotal"])
    elif result["virustotal"]:
        print(f"\n  VirusTotal: {result['virustotal']['note']}")
    if result["urlscan"]:
        print(f"\n  urlscan.io: {result['urlscan']['total']} total scans")
        for r in result["urlscan"]["recent"]:
            print(f"    - {r['url']} ({r['time']})")
    ok("URL analysis complete.")
