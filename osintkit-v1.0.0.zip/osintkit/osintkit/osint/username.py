"""Username / handle OSINT: check presence across public platforms.

Uses per-site URL patterns and response heuristics. Sites change their
markup often, so results are best-effort and should be manually verified
for anything evidential.
"""

import time

from ..utils import http_get, info, warn

# (site name, profile URL template, check type)
# check types: "status" (200 == exists), "404str" (page contains marker when missing)
SITES = [
    ("GitHub", "https://github.com/{u}", "status"),
    ("GitLab", "https://gitlab.com/{u}", "status"),
    ("Twitter/X", "https://x.com/{u}", "status"),
    ("Instagram", "https://www.instagram.com/{u}/", "status"),
    ("Reddit", "https://www.reddit.com/user/{u}/", "status"),
    ("YouTube", "https://www.youtube.com/@{u}", "status"),
    ("TikTok", "https://www.tiktok.com/@{u}", "status"),
    ("Twitch", "https://www.twitch.tv/{u}", "status"),
    ("Medium", "https://medium.com/@{u}", "status"),
    ("Pinterest", "https://www.pinterest.com/{u}/", "status"),
    ("Facebook", "https://www.facebook.com/{u}", "status"),
    ("LinkedIn", "https://www.linkedin.com/in/{u}", "status"),
    ("Telegram", "https://t.me/{u}", "status"),
    ("Mastodon", "https://mastodon.social/@{u}", "status"),
    ("Bluesky", "https://bsky.app/profile/{u}", "status"),
    ("Threads", "https://www.threads.net/@{u}", "status"),
    ("Snapchat", "https://www.snapchat.com/add/{u}", "status"),
    ("Spotify", "https://open.spotify.com/user/{u}", "status"),
    ("Steam", "https://steamcommunity.com/id/{u}", "status"),
    ("Docker Hub", "https://hub.docker.com/u/{u}", "status"),
    ("HackerNews", "https://news.ycombinator.com/user?id={u}", "hn"),
    ("PyPI", "https://pypi.org/user/{u}/", "status"),
    ("npm", "https://www.npmjs.com/~{u}", "status"),
    ("Keybase", "https://keybase.io/{u}", "status"),
    ("About.me", "https://about.me/{u}", "status"),
    ("Gravatar", "https://gravatar.com/{u}", "status"),
    ("Vimeo", "https://vimeo.com/{u}", "status"),
    ("Dailymotion", "https://www.dailymotion.com/{u}", "status"),
    ("DeviantArt", "https://www.deviantart.com/{u}", "status"),
    ("Flickr", "https://www.flickr.com/people/{u}/", "status"),
]


def check_site(name, url, kind, timeout=15):
    """Return (found: bool|None, detail). None = inconclusive."""
    try:
        status, headers, body = http_get(url, timeout=timeout)
    except RuntimeError:
        return None, "request failed"
    if kind == "status":
        ctype = headers.get("Content-Type", "")
        if status == 200:
            return True, f"HTTP 200 ({ctype.split(';')[0]})"
        if status in (404, 410):
            return False, f"HTTP {status}"
        return None, f"HTTP {status} (inconclusive)"
    if kind == "hn":
        text = body.decode("utf-8", "replace")
        if status == 200 and "No such user" not in text:
            return True, "profile page found"
        return False, "no such user"
    return None, "unknown check"


def run(args):
    from ..utils import emit_json, ok

    username = args.username.strip().lstrip("@")
    info(f"Checking handle '{username}' across {len(SITES)} platforms ...")
    found, not_found, unknown = [], [], []
    for name, template, kind in SITES:
        url = template.format(u=username)
        status, detail = check_site(name, url, kind)
        if status is True:
            found.append({"site": name, "url": url, "detail": detail})
        elif status is False:
            not_found.append(name)
        else:
            unknown.append({"site": name, "detail": detail})
        time.sleep(args.delay)

    result = {"username": username, "found": found,
              "not_found": not_found, "inconclusive": unknown}

    if args.json or args.output:
        emit_json(result, args.output)
        return

    print(f"\n  Handle: {username}")
    print(f"  Profiles found: {len(found)}")
    for f in found:
        print(f"    [+] {f['site']}: {f['url']}  ({f['detail']})")
    if unknown and args.verbose:
        print(f"  Inconclusive: {len(unknown)}")
        for u in unknown:
            print(f"    [?] {u['site']}: {u['detail']}")
    if not args.verbose:
        print(f"  (use --verbose to also list inconclusive checks)")
    warn("Verify hits manually before treating them as evidence.")
    ok("Username sweep complete.")
