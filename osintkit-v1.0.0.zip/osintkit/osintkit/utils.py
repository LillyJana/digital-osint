"""Shared helpers: HTTP, output formatting, filesystem utilities."""

import json
import sys
import urllib.error
import urllib.parse
import urllib.request

USER_AGENT = "OSINTKit/1.0 (investigative research; contact via operator)"


class Colors:
    OK = "\033[92m"
    INFO = "\033[94m"
    WARN = "\033[93m"
    ERR = "\033[91m"
    DIM = "\033[2m"
    BOLD = "\033[1m"
    END = "\033[0m"

    @classmethod
    def disable(cls):
        for attr in ("OK", "INFO", "WARN", "ERR", "DIM", "BOLD", "END"):
            setattr(cls, attr, "")


def supports_color():
    return sys.stdout.isatty() and sys.platform != "win32"


if not supports_color():
    Colors.disable()


_QUIET = False


def set_quiet(value=True):
    """Suppress progress chatter (used for clean --json output)."""
    global _QUIET
    _QUIET = value


def ok(msg):
    if _QUIET:
        return
    print(f"{Colors.OK}[+]{Colors.END} {msg}")


def info(msg):
    if _QUIET:
        return
    print(f"{Colors.INFO}[*]{Colors.END} {msg}")


def warn(msg):
    if _QUIET:
        print(f"{Colors.WARN}[!]{Colors.END} {msg}", file=sys.stderr)
    else:
        print(f"{Colors.WARN}[!]{Colors.END} {msg}")


def err(msg):
    print(f"{Colors.ERR}[-]{Colors.END} {msg}", file=sys.stderr)


def http_get(url, params=None, headers=None, timeout=20):
    """GET a URL, returning (status, headers_dict, body_bytes).

    Raises RuntimeError with a friendly message on network failure.
    """
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    req_headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
        except Exception:
            body = b""
        return exc.code, dict(exc.headers or {}), body
    except urllib.error.URLError as exc:
        raise RuntimeError(f"network error fetching {url}: {exc.reason}")
    except TimeoutError:
        raise RuntimeError(f"timed out fetching {url}")
    except Exception as exc:  # noqa: BLE001 - surface anything unexpected cleanly
        raise RuntimeError(f"request to {url} failed: {exc}")


def http_post_json(url, payload, headers=None, timeout=20):
    data = json.dumps(payload).encode("utf-8")
    req_headers = {
        "User-Agent": USER_AGENT,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, data=data, headers=req_headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
        except Exception:
            body = b""
        return exc.code, dict(exc.headers or {}), body
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"POST to {url} failed: {exc}")


def print_kv(title, mapping):
    """Print a titled block of key/value pairs."""
    print(f"\n{Colors.BOLD}{title}{Colors.END}")
    print("-" * max(len(title), 40))
    width = max((len(str(k)) for k in mapping), default=0)
    for key, value in mapping.items():
        if isinstance(value, (list, tuple)):
            value = ", ".join(str(v) for v in value) if value else "-"
        print(f"  {str(key).ljust(width)} : {value if value not in (None, '') else '-'}")


def print_list(title, items):
    print(f"\n{Colors.BOLD}{title}{Colors.END} ({len(items)})")
    print("-" * max(len(title), 40))
    for item in items:
        print(f"  - {item}")


def emit_json(obj, path=None):
    text = json.dumps(obj, indent=2, default=str)
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        ok(f"JSON written to {path}")
    else:
        print(text)


def chunked(path, size=65536):
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(size)
            if not chunk:
                break
            yield chunk


def human_size(num):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024 or unit == "TB":
            return f"{num:.1f} {unit}" if unit != "B" else f"{num} B"
        num /= 1024.0
